import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private http: HttpClient) { }
  url = 'https://api.myjson.com/bins/';
  getUsers(){
    return this
          .http
          .get(`${this.url}/tg8pe`)
  }
}
// nz1xu    data
