export interface User {
    id: Number;
    name: String;
    movies: Number;
  }